<?php

$servername="localhost";
$username="root";
$password="";
$database="computer_lab";

$conn=mysqli_connect($servername,$username,$password,$database) or die("Connection failed: " . mysqli_connect_error());
 ?>