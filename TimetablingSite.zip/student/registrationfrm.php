<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="reg.css">
</head>
<body>
    <div class="wrapper">

        <div class="registration_form">
       <!-- Title -->
         <div class="title">
         UPDATE YOUR DETAILS HERE
         </div>
       
       <!-- Form -->
        <form>
         <div class="form_wrap">
          <div class="input_grp">
       
       <!-- Frist name input Place -->
            <div class="input_wrap">
             <label for="fname">First Name</label>
             <input type="text" id="fname">
            </div>
       
       <!-- Last Name input place -->
           <div class="input_wrap">
             <label for="lname">Last Name</label>
             <input type="text" id="lname">
           </div>
         </div>
       
       <!-- Email Id input Place -->
        <div class="input_wrap">
         <label for="regno">Registration Number</label>
         <input type="text" id="email">
        </div>
       
       <!-- department name input place -->
        <div class="input_wrap">
         <label for="department">Department</label>
         <input type="text" id="city">
        </div>
       
       <!-- old password input place -->
        <div class="input_wrap">
         <label for="old password">old password</label>
         <input type="text" id="oldpassword">
        </div>
        <!-- old password input place -->
        <div class="input_wrap">
            <label for="new password"> New password</label>
            <input type="text" id="newpassword">
           </div>
          
       
       
       <!-- Submit button -->
        <div class="input_wrap">
          <input type="submit" value="UPDATE NOW" class="submit_btn">
        </div>
       
       </div>
       </form>
       </div>
       </div>
</body>
</html>